/*-execute-*/
create table test 
(
  a integer
);