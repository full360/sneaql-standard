/*-execute-*/
insert into test values(1);

/*-execute-*/
insert into test values(2);

/*-execute-*/
insert into test values(3);